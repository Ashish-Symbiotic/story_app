import 'package:flutter/material.dart';

class InsertNotes extends StatefulWidget {
  const InsertNotes({Key? key}) : super(key: key);

  @override
  _InsertNotesState createState() => _InsertNotesState();
}

class _InsertNotesState extends State<InsertNotes> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
